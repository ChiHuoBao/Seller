package com.example.dell.fragmentinfragment;

/**
 * Created by dell on 2016/3/2.
 */
public class DeliverMan {
    private String telephone;
    private int ImageId;
    private String name;

    public String getTelephone() {
        return telephone;
    }

    public int getImageId() {
        return ImageId;
    }

    public String getName() {
        return name;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public void setImageId(int imageId) {
        ImageId = imageId;
    }

    public void setName(String name) {
        this.name = name;
    }
}
