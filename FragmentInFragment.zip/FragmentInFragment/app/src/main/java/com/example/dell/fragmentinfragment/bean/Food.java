package com.example.dell.fragmentinfragment.bean;

import android.widget.ImageView;

/**
 * Created by dell on 2016/2/27.
 */
public class Food {
    private String type;
    private String name;
    private String description;
    private float price;
    private ImageView imageView;
}
